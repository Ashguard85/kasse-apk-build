# Änderungen: NFC-Status, responsives Tablet-Layout und Cloudflare Access

## Enthalten

- NFC-Box-Status wird ausgeblendet, wenn die Zahlungsmethode **NFC-Box** deaktiviert ist.
- Die NFC-Box verbindet nur automatisch, wenn die Methode aktiv ist.
- Kassenoberfläche wurde responsiver gemacht, damit auf kleineren Tablet-Displays weniger abgeschnitten wird.
- Artikelnamen und Preise in der Kasse sind grösser und kindgerechter lesbar.
- Android-App und Web-/Docker-App können Cloudflare-Access-Service-Token-Header mitsenden:
  - `CF-Access-Client-Id`
  - `CF-Access-Client-Secret`
- Backend-CORS erlaubt diese Header explizit.
- Ein Syntaxfehler in der Backend-Migration (`hasEmoji` doppelt deklariert) wurde korrigiert.

## Cloudflare Access wichtig

In Cloudflare Access muss für die geschützte Kassen-Anwendung eine **Service Auth** Policy mit deinem Service Token erlaubt sein. Nur die Header in der App einzutragen reicht nicht, wenn Cloudflare nur OTP/Login-Policy erlaubt.

Die Daten trägst du in der App ein unter:

`Einstellungen -> Cloudflare Access`

Danach unter `Einstellungen -> Server-Verbindung` die Tunnel-Adresse eintragen, zum Beispiel:

`https://kasse.deine-domain.ch`

## Docker neu bauen

```bash
docker compose down
docker compose up -d --build
```

## Android APK via GitHub Actions neu bauen

1. `kasse-source.zip` im GitHub-Repository ersetzen.
2. Workflow `Build Android APK` starten.
3. Artifact `kasse-debug-apk` herunterladen.
4. `app-debug.apk` auf dem Tablet installieren.
