# KinderKasse Android 2.2.0

Dieses Quellpaket ist für den bestehenden GitHub-Workflow mit dem Dateinamen `kasse-source.zip` vorbereitet.

## Bestehenden GitHub-Workflow weiterverwenden

1. `kasse-source.zip` unverändert im Stammverzeichnis des GitHub-Repositorys ablegen.
2. Den vorhandenen Workflow beibehalten. Er entpackt das Paket mit `unzip -q kasse-source.zip`.
3. Der Quellcode liegt danach wie erwartet unter `kasse/frontend`.
4. Unter **Actions → Build Android APK → Run workflow** den Build starten.
5. Das Artefakt `kasse-debug-apk` herunterladen.

Die erwartete APK liegt im Workflow unter:

```text
kasse/frontend/android/app/build/outputs/apk/debug/app-debug.apk
```

## Lokal bauen

```bash
unzip kasse-source.zip
cd kasse/frontend
npm install --include=dev
npm run build
npx cap sync android
cd android
./gradlew assembleDebug
```

Ergebnis:

```text
kasse/frontend/android/app/build/outputs/apk/debug/app-debug.apk
```

## Mit Docker verbinden

In der installierten App:

1. **Einstellungen** öffnen.
2. **Server verwenden** aktivieren.
3. Die Adresse der Docker-Webapp eintragen, zum Beispiel `http://192.168.1.50:3800` oder die HTTPS-Domain.
4. Verbindung testen.

Die Serveradresse verweist auf die Webapp, nicht direkt auf den Backend-Port.

## Profile und Designs

Der Profilwechsel befindet sich nur in den Einstellungen. Das zuletzt ausgewählte Profil wird auf dem Gerät gespeichert. Neue Profile können jederzeit angelegt und archiviert werden.

Jedes Profil unterstützt:

- eigene Produkte, Guthaben, Bons und Statistiken
- acht fertige Designvorlagen
- Hell-/Dunkelmodus
- eigene Farben, Logo und Bannerbild
- automatische Kontrastfarben und Live-Vorschau

## Veröffentlichungshinweis

Der bestehende Workflow erzeugt eine Debug-APK. Für eine signierte Release-APK müssen ein Android-Keystore und die zugehörigen GitHub-Secrets ergänzt werden.
