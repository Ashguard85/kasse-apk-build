# KinderKasse Android 2.8.0

Dieses Quellpaket ist für den bestehenden GitHub-Workflow mit dem Dateinamen
`kasse-source.zip` vorbereitet.

## GitHub-Workflow

1. `kasse-source.zip` unverändert im Repository-Stamm ablegen.
2. Vorhandenen Workflow weiterverwenden.
3. Der Workflow entpackt nach `kasse/`.
4. Release-/Signierungs-Secrets bleiben wie bisher in GitHub hinterlegt.
5. Der `.jks`-Keystore gehört nicht ins ZIP.

Android-Version:
- versionName `2.8.0`
- versionCode `15`

## Docker-Verbindung

Einstellungen → Betriebsmodus → Server verwenden.

Beispiel:
`http://192.168.1.50:3800`

Bei Cloudflare/Reverse Proxy die HTTPS-Domain verwenden.

## Lokaler Modus

Ohne Docker bleiben lokale Datenhaltung und lokale Zusatzgeräte verfügbar:
- NFC-Box via BLE
- ESP32-S3 Kundendisplay via BLE
- zweites Tablet/Handy via WLAN/Hotspot
- ESP32-C3 Kassenschublade via BLE

## Zusatzgeräte

Die jeweiligen Firmware-/Quellpakete liegen unter `devices/`.

- NFC: `devices/nfc-box/`
- Kundendisplay: `devices/KinderKasse-DisplayBox-ESP32-S3-v1.2.0.zip`
- Kassenschublade: `devices/KinderKasse-Drawer-ESP32-C3-v1.0.0.zip`

Alle Zusatzfunktionen sind optional.
