# KinderKasse Android APK bauen

Diese Version ist als Capacitor-Android-App vorbereitet.

## Enthalten

- Native BLE-Verbindung zur NFC-Box `KasseNFC`
- Service UUID: `7a0f0001-1b55-4e2a-9c2e-9a6b9f3a2c10`
- UID Characteristic: `7a0f0002-1b55-4e2a-9c2e-9a6b9f3a2c10`
- Automatisches Scannen/Verbinden in der Android-App ohne Web-Bluetooth-Geräteliste
- Android-Bluetooth-Berechtigungen im Manifest
- Einstellung für die Server-Adresse in der App unter: Einstellungen -> Server-Verbindung

## Wichtig

Die APK enthält nur die Tablet-App. Das Backend bleibt dein Docker/Server-Backend.
In der App unter Einstellungen die Server-Adresse eintragen, z.B.:

- `https://deine-kasse-domain.ch`
- oder `http://192.168.1.50:3800`

Bei HTTP im lokalen Netz wurde `android:usesCleartextTraffic="true"` gesetzt.

## APK bauen mit Android Studio

1. Android Studio installieren.
2. Dieses Projekt entpacken.
3. Terminal im Ordner `kasse/frontend` öffnen.
4. Ausführen:

```bash
npm install
npm run build
npx cap sync android
```

5. In Android Studio den Ordner öffnen:

```text
kasse/frontend/android
```

6. Dann:

```text
Build -> Build Bundle(s) / APK(s) -> Build APK(s)
```

Die Debug-APK liegt danach normalerweise unter:

```text
kasse/frontend/android/app/build/outputs/apk/debug/app-debug.apk
```

## Installation auf dem Tablet

1. APK aufs Tablet kopieren.
2. Installation aus unbekannten Quellen erlauben.
3. App öffnen.
4. Android-Berechtigung „Geräte in der Nähe“ erlauben.
5. Unter Einstellungen die Server-Adresse speichern.
6. NFC-Box einschalten; die App scannt automatisch nach `KasseNFC`.
