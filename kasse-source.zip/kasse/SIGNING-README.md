# KinderKasse Android Release-Signierung

Version: 2.1.3
Android versionCode: 6

Ab Version 2.1.3 wird die Android-App als dauerhaft signierte Release-APK gebaut. Dadurch können spätere APK-Versionen als Update über die bestehende Installation installiert werden, solange derselbe Keystore verwendet und der Android `versionCode` erhöht wird.

## Einmalige GitHub-Secrets

Im GitHub-Repository unter **Settings > Secrets and variables > Actions** diese vier Repository Secrets anlegen:

- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

Die Werte befinden sich in der separat gelieferten Datei `KinderKasse-GitHub-Signing-Secrets-2.1.3.txt`. Diese Datei und der `.jks`-Keystore dürfen nicht ins Git-Repository eingecheckt werden.

## Einmaliger Wechsel von Debug auf Release

Eine bereits installierte, anders signierte Debug-APK kann nicht direkt mit der ersten Release-APK überschrieben werden. Diese alte App muss einmal deinstalliert und Version 2.1.3 neu installiert werden. Ab dann können spätere Releases mit demselben Key direkt darüber installiert werden.

## Sicherung

Den Keystore und die Passwörter dauerhaft sichern. Bei Verlust des privaten Signing-Keys kann eine vorhandene Installation nicht mehr mit einer neu signierten APK aktualisiert werden.
