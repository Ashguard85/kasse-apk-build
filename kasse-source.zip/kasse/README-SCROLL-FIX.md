# Scroll-Fix

Diese APK-Quelle enthält denselben Scroll-Fix wie die Webapp.
Die native NFC-Box-Verbindung bleibt unverändert.
