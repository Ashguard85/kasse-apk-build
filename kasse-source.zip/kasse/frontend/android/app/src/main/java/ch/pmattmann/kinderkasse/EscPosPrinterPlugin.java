package ch.pmattmann.kinderkasse;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Build;
import android.util.Base64;

import androidx.core.app.ActivityCompat;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.Set;
import java.util.UUID;

@CapacitorPlugin(name = "EscPosPrinter")
public class EscPosPrinterPlugin extends Plugin {
    private static final int REQUEST_BLUETOOTH_CONNECT = 4210;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @PluginMethod
    public void requestPrinterPermission(PluginCall call) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !hasBluetoothConnectPermission()) {
            ActivityCompat.requestPermissions(
                    getActivity(),
                    new String[]{Manifest.permission.BLUETOOTH_CONNECT},
                    REQUEST_BLUETOOTH_CONNECT
            );
            JSObject ret = new JSObject();
            ret.put("requested", true);
            ret.put("granted", false);
            call.resolve(ret);
            return;
        }
        JSObject ret = new JSObject();
        ret.put("requested", false);
        ret.put("granted", true);
        call.resolve(ret);
    }

    @PluginMethod
    public void listBondedDevices(PluginCall call) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !hasBluetoothConnectPermission()) {
            call.reject("Bluetooth-Berechtigung fehlt. Bitte erlauben und erneut versuchen.");
            return;
        }

        BluetoothAdapter adapter = getBluetoothAdapter();
        if (adapter == null) {
            call.reject("Bluetooth ist auf diesem Gerät nicht verfügbar.");
            return;
        }
        if (!adapter.isEnabled()) {
            call.reject("Bluetooth ist ausgeschaltet.");
            return;
        }

        JSArray devices = new JSArray();
        try {
            Set<BluetoothDevice> bonded = adapter.getBondedDevices();
            for (BluetoothDevice device : bonded) {
                String name = device.getName();
                if (name == null || name.trim().isEmpty()) name = "Unbekanntes Gerät";
                JSObject item = new JSObject();
                item.put("name", name);
                item.put("address", device.getAddress());
                item.put("printerLikely", isLikelyPrinter(name));
                devices.put(item);
            }
        } catch (SecurityException e) {
            call.reject("Bluetooth-Berechtigung fehlt.");
            return;
        }

        JSObject ret = new JSObject();
        ret.put("devices", devices);
        call.resolve(ret);
    }

    @PluginMethod
    public void printText(PluginCall call) {
        String address = call.getString("address");
        String text = call.getString("text", "");
        String codePage = call.getString("codePage", "cp858");
        String textStyle = call.getString("textStyle", "normal");
        Boolean printLogoValue = call.getBoolean("printLogo", false);
        boolean printLogo = printLogoValue != null && printLogoValue;
        String logoData = call.getString("logoData", "");
        Integer logoWidthValue = call.getInt("logoWidthPx", 384);
        int logoWidthPx = logoWidthValue != null ? logoWidthValue : 384;
        Integer logoMaxHeightValue = call.getInt("logoMaxHeightPx", 260);
        int logoMaxHeightPx = logoMaxHeightValue != null ? logoMaxHeightValue : 260;

        if (address == null || address.trim().isEmpty()) {
            call.reject("Kein Drucker ausgewählt.");
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !hasBluetoothConnectPermission()) {
            call.reject("Bluetooth-Berechtigung fehlt. Bitte in Android erlauben.");
            return;
        }

        new Thread(() -> {
            BluetoothSocket socket = null;
            try {
                BluetoothAdapter adapter = getBluetoothAdapter();
                if (adapter == null) throw new Exception("Bluetooth ist nicht verfügbar.");
                if (!adapter.isEnabled()) throw new Exception("Bluetooth ist ausgeschaltet.");

                try { adapter.cancelDiscovery(); } catch (SecurityException ignored) {}
                BluetoothDevice device = adapter.getRemoteDevice(address);
                socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                socket.connect();

                Charset charset = charsetForCodePage(codePage);
                OutputStream out = socket.getOutputStream();
                out.write(new byte[]{0x1B, 0x40}); // ESC @ - init
                configureCodePage(out, codePage);

                if (printLogo && logoData != null && !logoData.trim().isEmpty()) {
                    Bitmap logo = decodeLogoBitmap(logoData);
                    if (logo != null) {
                        out.write(new byte[]{0x1B, 0x61, 0x01}); // ESC a 1 - center
                        writeBitmap(out, logo, logoWidthPx, logoMaxHeightPx);
                        out.write(new byte[]{0x1B, 0x61, 0x00}); // ESC a 0 - left
                        out.write(new byte[]{0x0A});
                    }
                }

                writeTextStyle(out, textStyle);
                out.write(text.getBytes(charset));
                out.write(new byte[]{0x1B, 0x45, 0x00}); // bold off
                out.write(new byte[]{0x1D, 0x21, 0x00}); // size normal
                out.write(new byte[]{0x1B, 0x4D, 0x00}); // font A
                out.write(new byte[]{0x0A, 0x0A, 0x0A, 0x0A}); // paper feed, no cutter on PT-210
                out.flush();

                JSObject ret = new JSObject();
                ret.put("ok", true);
                call.resolve(ret);
            } catch (Exception e) {
                call.reject("Druck fehlgeschlagen: " + (e.getMessage() != null ? e.getMessage() : e.toString()));
            } finally {
                if (socket != null) {
                    try { socket.close(); } catch (Exception ignored) {}
                }
            }
        }).start();
    }


    @PluginMethod
    public void printImage(PluginCall call) {
        String address = call.getString("address");
        String imageData = call.getString("imageData", "");
        Integer widthValue = call.getInt("widthPx", 384);
        int widthPx = widthValue != null ? widthValue : 384;

        if (address == null || address.trim().isEmpty()) {
            call.reject("Kein Drucker ausgewählt.");
            return;
        }
        if (imageData == null || imageData.trim().isEmpty()) {
            call.reject("Kein Bonbild erhalten.");
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !hasBluetoothConnectPermission()) {
            call.reject("Bluetooth-Berechtigung fehlt. Bitte in Android erlauben.");
            return;
        }

        new Thread(() -> {
            BluetoothSocket socket = null;
            try {
                BluetoothAdapter adapter = getBluetoothAdapter();
                if (adapter == null) throw new Exception("Bluetooth ist nicht verfügbar.");
                if (!adapter.isEnabled()) throw new Exception("Bluetooth ist ausgeschaltet.");

                try { adapter.cancelDiscovery(); } catch (SecurityException ignored) {}
                BluetoothDevice device = adapter.getRemoteDevice(address);
                socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                socket.connect();

                Bitmap receipt = decodeLogoBitmap(imageData);
                if (receipt == null) throw new Exception("Bonbild konnte nicht gelesen werden.");

                OutputStream out = socket.getOutputStream();
                out.write(new byte[]{0x1B, 0x40}); // ESC @ - init
                out.write(new byte[]{0x1B, 0x61, 0x01}); // ESC a 1 - center
                writeBitmap(out, receipt, widthPx, 0);
                out.write(new byte[]{0x1B, 0x61, 0x00}); // ESC a 0 - left
                out.write(new byte[]{0x0A, 0x0A, 0x0A, 0x0A});
                out.flush();

                JSObject ret = new JSObject();
                ret.put("ok", true);
                call.resolve(ret);
            } catch (Exception e) {
                call.reject("Bilddruck fehlgeschlagen: " + (e.getMessage() != null ? e.getMessage() : e.toString()));
            } finally {
                if (socket != null) {
                    try { socket.close(); } catch (Exception ignored) {}
                }
            }
        }).start();
    }


    private Bitmap decodeLogoBitmap(String base64Data) {
        try {
            String clean = base64Data == null ? "" : base64Data.trim();
            int comma = clean.indexOf(',');
            if (comma >= 0) clean = clean.substring(comma + 1);
            byte[] data = Base64.decode(clean, Base64.DEFAULT);
            return BitmapFactory.decodeByteArray(data, 0, data.length);
        } catch (Exception e) {
            return null;
        }
    }

    private void writeBitmap(OutputStream out, Bitmap source, int requestedWidth) throws Exception {
        writeBitmap(out, source, requestedWidth, 220);
    }

    private void writeBitmap(OutputStream out, Bitmap source, int requestedWidth, int maxHeight) throws Exception {
        Bitmap prepared = prepareMonochromeBitmap(source, requestedWidth, maxHeight);
        int width = prepared.getWidth();
        int height = prepared.getHeight();
        int bytesPerRow = (width + 7) / 8;
        int maxChunkHeight = 240;

        for (int chunkTop = 0; chunkTop < height; chunkTop += maxChunkHeight) {
            int chunkHeight = Math.min(maxChunkHeight, height - chunkTop);
            ByteArrayOutputStream imageBytes = new ByteArrayOutputStream(bytesPerRow * chunkHeight);

            for (int y = chunkTop; y < chunkTop + chunkHeight; y++) {
                for (int xByte = 0; xByte < bytesPerRow; xByte++) {
                    int value = 0;
                    for (int bit = 0; bit < 8; bit++) {
                        int x = xByte * 8 + bit;
                        if (x < width && isBlack(prepared.getPixel(x, y))) {
                            value |= (1 << (7 - bit));
                        }
                    }
                    imageBytes.write(value);
                }
            }

            out.write(new byte[]{
                    0x1D, 0x76, 0x30, 0x00,
                    (byte) (bytesPerRow & 0xFF),
                    (byte) ((bytesPerRow >> 8) & 0xFF),
                    (byte) (chunkHeight & 0xFF),
                    (byte) ((chunkHeight >> 8) & 0xFF)
            });
            out.write(imageBytes.toByteArray());
        }
    }

    private Bitmap prepareMonochromeBitmap(Bitmap source, int requestedWidth, int maxHeight) {
        int targetWidth = Math.max(80, Math.min(384, requestedWidth));
        int srcWidth = Math.max(1, source.getWidth());
        int srcHeight = Math.max(1, source.getHeight());
        float scale = (float) targetWidth / (float) srcWidth;
        int targetHeight = Math.max(1, Math.round(srcHeight * scale));
        if (maxHeight > 0 && targetHeight > maxHeight) {
            scale = (float) maxHeight / (float) srcHeight;
            targetHeight = maxHeight;
            targetWidth = Math.max(80, Math.round(srcWidth * scale));
        }
        if (maxHeight <= 0 && targetHeight > 5000) {
            scale = 5000f / (float) srcHeight;
            targetHeight = 5000;
            targetWidth = Math.max(80, Math.round(srcWidth * scale));
        }

        int rasterWidth = ((targetWidth + 7) / 8) * 8;
        Bitmap output = Bitmap.createBitmap(rasterWidth, targetHeight, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);
        canvas.drawColor(Color.WHITE);

        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
        int left = Math.max(0, (rasterWidth - targetWidth) / 2);
        Rect dst = new Rect(left, 0, left + targetWidth, targetHeight);
        canvas.drawBitmap(source, null, dst, paint);
        return output;
    }

    private boolean isBlack(int color) {
        int alpha = Color.alpha(color);
        if (alpha < 128) return false;
        int red = Color.red(color);
        int green = Color.green(color);
        int blue = Color.blue(color);
        int luminance = (red * 299 + green * 587 + blue * 114) / 1000;
        return luminance < 170;
    }

    private void writeTextStyle(OutputStream out, String textStyle) throws Exception {
        String style = textStyle == null ? "normal" : textStyle;
        boolean small = style.equals("small");
        boolean bold = style.equals("bold") || style.equals("largeBold");
        boolean large = style.equals("large") || style.equals("largeBold");

        out.write(new byte[]{0x1B, 0x4D, (byte) (small ? 0x01 : 0x00)}); // ESC M - Font B/A
        out.write(new byte[]{0x1B, 0x45, (byte) (bold ? 0x01 : 0x00)}); // ESC E - bold
        out.write(new byte[]{0x1D, 0x21, (byte) (large ? 0x01 : 0x00)}); // GS ! - double height only
    }

    private void configureCodePage(OutputStream out, String codePage) throws Exception {
        String cp = normalizeCodePageName(codePage);
        if (cp.equals("pc936")) {
            // Viele PT-210/GOOJPRT-Varianten melden auf dem Selbsttest PC936/GB18030.
            // Für diesen Modus ist die sicherste Variante: Drucker nach ESC @ auf seiner
            // Standardsprache lassen und nur GB18030-kodierte Bytes senden. FS & ist ein
            // üblicher ESC/POS-Schalter für chinesischen Zeichenmodus; wenn der Drucker
            // ihn ignoriert, bleibt ASCII/Text trotzdem druckbar.
            out.write(new byte[]{0x1C, 0x26}); // FS & - Chinese character mode on
            return;
        }
        out.write(new byte[]{0x1B, 0x74, escPosCodePageNumber(cp)}); // ESC t n - code page
    }

    private String normalizeCodePageName(String codePage) {
        String cp = codePage == null ? "cp858" : codePage.toLowerCase().trim();
        if (cp.equals("gb18030") || cp.equals("gbk") || cp.equals("cp936")) return "pc936";
        if (cp.equals("iso-8859-15") || cp.equals("iso_8859_15") || cp.equals("latin9") || cp.equals("latin-9")) return "iso885915";
        return cp;
    }

    private byte escPosCodePageNumber(String codePage) {
        String cp = normalizeCodePageName(codePage);
        switch (cp) {
            case "iso885915":
                return 0x28; // ISO-8859-15 / Latin-9 on PT-210 style ESC/POS printers
            case "cp850":
                return 0x02; // PC850 Multilingual on common ESC/POS printers
            case "windows1252":
                return 0x10; // WPC1252 on many ESC/POS clones
            case "cp437":
                return 0x00; // USA Standard Europe
            case "cp858":
            default:
                return 0x13; // PC858 Euro on many ESC/POS clones
        }
    }

    private Charset charsetForCodePage(String codePage) {
        String cp = codePage == null ? "cp858" : codePage.toLowerCase();
        cp = normalizeCodePageName(cp);
        if (cp.equals("pc936")) return firstAvailableCharset("GB18030", "GBK", "CP936", "MS936");
        if (cp.equals("iso885915")) return firstAvailableCharset("ISO-8859-15", "ISO8859_15", "latin9", "Latin9");
        if (cp.equals("cp850")) return firstAvailableCharset("CP850", "IBM850", "ibm-850");
        if (cp.equals("windows1252")) return firstAvailableCharset("windows-1252", "Cp1252", "CP1252");
        if (cp.equals("cp437")) return firstAvailableCharset("CP437", "IBM437", "ibm-437");
        return firstAvailableCharset("CP858", "IBM00858", "ibm-858", "CP850", "IBM850");
    }

    private Charset firstAvailableCharset(String... names) {
        for (String name : names) {
            try {
                if (Charset.isSupported(name)) return Charset.forName(name);
            } catch (Exception ignored) {}
        }
        return Charset.defaultCharset();
    }

    private BluetoothAdapter getBluetoothAdapter() {
        BluetoothManager manager = (BluetoothManager) getContext().getSystemService(Context.BLUETOOTH_SERVICE);
        return manager != null ? manager.getAdapter() : BluetoothAdapter.getDefaultAdapter();
    }

    private boolean hasBluetoothConnectPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true;
        return ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean isLikelyPrinter(String name) {
        String lower = name.toLowerCase();
        return lower.contains("pt-210")
                || lower.contains("goojprt")
                || lower.contains("printer")
                || lower.contains("pos")
                || lower.contains("mtp")
                || lower.contains("58");
    }
}
