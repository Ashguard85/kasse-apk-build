package ch.pmattmann.kinderkasse;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Collections;

@CapacitorPlugin(name = "LocalDisplayServer")
public class LocalDisplayServerPlugin extends Plugin {
    private static final int PORT = 3890;
    private volatile boolean running = false;
    private volatile String stateJson = "{\"status\":\"shop\",\"items\":[],\"total\":0}";
    private volatile String inputJson = "";
    private ServerSocket serverSocket;
    private Thread serverThread;

    @PluginMethod
    public void start(PluginCall call) {
        if (!running) {
            running = true;
            serverThread = new Thread(this::runServer, "KinderKasseDisplayServer");
            serverThread.start();
        }
        JSObject result = buildInfo();
        call.resolve(result);
    }

    @PluginMethod
    public void stop(PluginCall call) {
        running = false;
        try { if (serverSocket != null) serverSocket.close(); } catch (Exception ignored) {}
        serverSocket = null;
        call.resolve();
    }

    @PluginMethod
    public void updateState(PluginCall call) {
        String json = call.getString("json");
        if (json != null && !json.isEmpty()) stateJson = json;
        call.resolve();
    }

    @PluginMethod
    public void consumeInput(PluginCall call) {
        JSObject result = new JSObject();
        String value = inputJson;
        inputJson = "";
        result.put("json", value);
        call.resolve(result);
    }

    @PluginMethod
    public void getInfo(PluginCall call) {
        call.resolve(buildInfo());
    }

    private JSObject buildInfo() {
        JSObject result = new JSObject();
        result.put("running", running);
        result.put("port", PORT);
        String ip = getLanIpv4();
        result.put("ip", ip);
        result.put("url", ip.isEmpty() ? "" : "http://" + ip + ":" + PORT + "/state");
        return result;
    }

    private void runServer() {
        try {
            serverSocket = new ServerSocket(PORT);
            serverSocket.setReuseAddress(true);
            while (running) {
                Socket client = serverSocket.accept();
                handle(client);
            }
        } catch (Exception ignored) {
        } finally {
            running = false;
            try { if (serverSocket != null) serverSocket.close(); } catch (Exception ignored) {}
            serverSocket = null;
        }
    }

    private void handle(Socket socket) {
        try (Socket client = socket;
             BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream(), StandardCharsets.UTF_8));
             BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream(), StandardCharsets.UTF_8))) {

            String request = in.readLine();
            if (request == null) return;
            String line;
            int contentLength = 0;
            while ((line = in.readLine()) != null && !line.isEmpty()) {
                if (line.toLowerCase().startsWith("content-length:")) {
                    try { contentLength = Integer.parseInt(line.substring(15).trim()); } catch (Exception ignored) {}
                }
            }

            boolean state = request.startsWith("GET /state ");
            boolean input = request.startsWith("POST /input ");
            boolean options = request.startsWith("OPTIONS ");

            if (options) {
                out.write("HTTP/1.1 204 No Content\r\n");
                writeCors(out);
                out.write("Content-Length: 0\r\nConnection: close\r\n\r\n");
            } else if (input) {
                char[] buf = new char[Math.max(0, Math.min(contentLength, 2048))];
                int got = 0;
                while (got < buf.length) {
                    int n = in.read(buf, got, buf.length - got);
                    if (n < 0) break;
                    got += n;
                }
                inputJson = new String(buf, 0, got);
                byte[] body = "{\"success\":true}".getBytes(StandardCharsets.UTF_8);
                out.write("HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n");
                writeCors(out);
                out.write("Content-Length: " + body.length + "\r\nConnection: close\r\n\r\n");
                out.flush();
                client.getOutputStream().write(body);
            } else if (state) {
                byte[] body = stateJson.getBytes(StandardCharsets.UTF_8);
                out.write("HTTP/1.1 200 OK\r\n");
                out.write("Content-Type: application/json; charset=utf-8\r\n");
                writeCors(out);
                out.write("Cache-Control: no-store\r\n");
                out.write("Content-Length: " + body.length + "\r\n");
                out.write("Connection: close\r\n\r\n");
                out.flush();
                client.getOutputStream().write(body);
            } else {
                byte[] body = "{\"error\":\"not found\"}".getBytes(StandardCharsets.UTF_8);
                out.write("HTTP/1.1 404 Not Found\r\nContent-Type: application/json\r\n");
                writeCors(out);
                out.write("Content-Length: " + body.length + "\r\nConnection: close\r\n\r\n");
                out.flush();
                client.getOutputStream().write(body);
            }
            client.getOutputStream().flush();
        } catch (Exception ignored) {}
    }

    private void writeCors(BufferedWriter out) throws Exception {
        out.write("Access-Control-Allow-Origin: *\r\n");
        out.write("Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n");
        out.write("Access-Control-Allow-Headers: Content-Type\r\n");
    }

    private String getLanIpv4() {
        try {
            for (NetworkInterface iface : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!iface.isUp() || iface.isLoopback()) continue;
                for (InetAddress addr : Collections.list(iface.getInetAddresses())) {
                    if (addr instanceof Inet4Address && !addr.isLoopbackAddress()) {
                        String host = addr.getHostAddress();
                        if (host != null && !host.startsWith("169.254.")) return host;
                    }
                }
            }
        } catch (Exception ignored) {}
        return "";
    }
}
