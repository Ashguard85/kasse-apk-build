package ch.pmattmann.kinderkasse;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
