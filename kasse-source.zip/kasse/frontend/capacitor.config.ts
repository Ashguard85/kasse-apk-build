import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'ch.pmattmann.kinderkasse',
  appName: 'KinderKasse',
  webDir: 'dist'
};

export default config;
