import React, { useState, useEffect, useRef } from "react";
import styles from "./Karten.module.css";
import QrCode from "../components/QrCode";
import { useNfc } from "../NfcContext";
import { api } from "../lib/api";

function priceStr(n) {
  return Number(n).toFixed(2) + " CHF";
}

export default function Karten() {
  const nfc = useNfc(); // geteilte, app-weite NFC-Box-Verbindung
  const [customers, setCustomers] = useState([]);
  const [name, setName] = useState("");
  const [initType, setInitType] = useState("both"); // nfc | qr | both | none
  const [initUid, setInitUid] = useState("");
  const [initQr, setInitQr] = useState("");
  const [balance, setBalance] = useState("");

  const [topupId, setTopupId] = useState("");
  const [topupAmount, setTopupAmount] = useState("");

  const [scanning, setScanning] = useState(false); // "nfc" | "qr" | false
  const [scanTarget, setScanTarget] = useState(null);
  const [msg, setMsg] = useState({ text: "", type: "" });
  const [transactions, setTransactions] = useState([]);
  const [selected, setSelected] = useState(null);
  const [showQr, setShowQr] = useState(null);
  const [showOverview, setShowOverview] = useState(false);

  // Add-token form (within selected customer detail)
  const [newTokenType, setNewTokenType] = useState("nfc");
  const [newTokenValue, setNewTokenValue] = useState("");

  const videoRef = useRef(null);
  const scannerRef = useRef(null);
  const bleDisconnectRef = useRef(null); // Trennt die ESP32-Bluetooth-NFC-Box
  const msgTimerRef = useRef(null); // Fix #5 (Review 4): verhindert Race Condition bei schnell aufeinanderfolgenden Meldungen

  const fetchCustomers = async () => {
    try {
      const res = await fetch(api(`/api/customers`));
      if (!res.ok) throw new Error("Server-Fehler");
      setCustomers(await res.json());
    } catch (e) {
      showMsg("Server nicht erreichbar", "err");
    }
  };

  useEffect(() => { fetchCustomers(); }, []);
  useEffect(() => () => { stopQrScan(); stopNfcScan(); if (msgTimerRef.current) clearTimeout(msgTimerRef.current); }, []);

  const showMsg = (text, type = "ok") => {
    if (msgTimerRef.current) clearTimeout(msgTimerRef.current);
    setMsg({ text, type });
    msgTimerRef.current = setTimeout(() => setMsg({ text: "", type: "" }), 3000);
  };

  // ── NFC (über ESP32-Bluetooth-Box) / QR scanning ──
  // Das Lenovo Tab M11 hat kein eigenes NFC, daher läuft das Kartenlesen
  // hier — genau wie in der Kasse — über die geteilte ESP32-Bluetooth-Box
  // aus dem NfcContext (eine app-weite Verbindung für alle Bereiche).
  const scanNfc = async (target) => {
    if (!nfc.isSupported) {
      return showMsg("Web Bluetooth nicht verfügbar — bitte Chrome auf Android verwenden", "err");
    }
    setScanTarget(target);
    setScanning("nfc");
    // Falls noch nicht verbunden: jetzt verbinden (Klick = Nutzergeste)
    if (nfc.status !== "connected") {
      showMsg("Verbinde mit NFC-Box …", "ok");
      const ok = await nfc.connect(true);
      if (!ok) {
        showMsg("NFC-Box nicht verbunden. Oben auf „neu verbinden“ tippen.", "err");
        setScanning(false);
        setScanTarget(null);
        return;
      }
    }
    showMsg("Karte an die NFC-Box halten …", "ok");
    bleDisconnectRef.current = nfc.subscribeUid((uid) => {
      applyScanResult(target, uid);
      showMsg("NFC-Karte gelesen ✓");
      stopNfcScan();
    });
  };

  const stopNfcScan = () => {
    // Nur das Abo beenden — die geteilte Verbindung bleibt offen.
    if (bleDisconnectRef.current) {
      bleDisconnectRef.current();
      bleDisconnectRef.current = null;
    }
    setScanning(false);
    setScanTarget(null);
  };

  const scanQr = async (target) => {
    if (!("BarcodeDetector" in window)) {
      showMsg("QR-Scan auf diesem Gerät nicht verfügbar – bitte Chrome aktualisieren", "err");
      return;
    }
    // Fix #7 (Review 2): expliziter Check, sonst kommt eine kryptische
    // "Cannot read properties of undefined"-Meldung statt einer klaren Erklärung
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      showMsg("Kamera nicht verfügbar — die Seite muss über HTTPS aufgerufen werden", "err");
      return;
    }
    setScanTarget(target);
    setScanning("qr");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
      if (videoRef.current) { videoRef.current.srcObject = stream; videoRef.current.play(); }
      const detector = new BarcodeDetector({ formats: ["qr_code"] });
      const scan = async () => {
        if (!videoRef.current || videoRef.current.readyState < 2) {
          scannerRef.current = requestAnimationFrame(scan);
          return;
        }
        try {
          const codes = await detector.detect(videoRef.current);
          if (codes.length > 0) {
            stopQrScan();
            applyScanResult(target, codes[0].rawValue);
            return;
          }
        } catch (_) {}
        scannerRef.current = requestAnimationFrame(scan);
      };
      scannerRef.current = requestAnimationFrame(scan);
    } catch (e) {
      if (e.name === "NotAllowedError") {
        showMsg("Kamera-Zugriff verweigert. Bitte in den Browser-Einstellungen erlauben.", "err");
      } else if (e.name === "NotFoundError") {
        showMsg("Keine Kamera gefunden.", "err");
      } else {
        showMsg("Kamera Fehler: " + e.message, "err");
      }
      setScanning(false);
      setScanTarget(null);
    }
  };

  const stopQrScan = () => {
    if (scannerRef.current) { cancelAnimationFrame(scannerRef.current); scannerRef.current = null; }
    if (videoRef.current?.srcObject) {
      videoRef.current.srcObject.getTracks().forEach(t => t.stop());
      videoRef.current.srcObject = null;
    }
    setScanning(false);
    setScanTarget(null);
  };

  const applyScanResult = (target, value) => {
    if (target === "new-nfc") setInitUid(value);
    else if (target === "new-qr") setInitQr(value);
    else if (target === "topup") setTopupId(value);
    else if (target === "add-token") setNewTokenValue(value);
  };

  const genQrId = (setter) => {
    const rand = Math.random().toString(36).substring(2, 8).toUpperCase();
    setter(`KASSE-${rand}`);
  };

  // ── Create customer ──
  const createCustomer = async () => {
    if (!name) return showMsg("Bitte Namen eingeben", "err");
    const needsUid = initType === "nfc" || initType === "both";
    const needsQr = initType === "qr" || initType === "both";
    if (needsUid && !initUid) return showMsg("Bitte NFC-UID eingeben/scannen", "err");
    if (needsQr && !initQr) return showMsg("Bitte QR-Code eingeben/scannen/generieren", "err");

    try {
      const res = await fetch(api(`/api/customers`), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name,
          balance: parseFloat(balance) || 0,
          nfc_uid: needsUid ? initUid : null,
          qr_code: needsQr ? initQr : null,
        }),
      });
      if (res.ok) {
        showMsg(`Kunde "${name}" erstellt ✓`);
        setName(""); setInitUid(""); setInitQr(""); setBalance("");
        fetchCustomers();
      } else {
        const d = await res.json();
        showMsg(d.error, "err");
      }
    } catch (e) {
      showMsg("Server nicht erreichbar", "err");
    }
  };

  // ── Topup ──
  const topup = async () => {
    if (!topupId || !topupAmount) return;
    try {
      const lookup = await fetch(api(`/api/lookup/${encodeURIComponent(topupId)}`));
      if (!lookup.ok) return showMsg("Kunde nicht gefunden", "err");
      const customer = await lookup.json();
      const res = await fetch(api(`/api/customers/${customer.id}/topup`), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount: parseFloat(topupAmount) }),
      });
      if (res.ok) {
        const updated = await res.json();
        showMsg(`Aufgeladen! Guthaben: ${priceStr(updated.balance)}`);
        setTopupId(""); setTopupAmount("");
        fetchCustomers();
        if (selected?.id === customer.id) selectCustomer(updated);
      } else {
        const d = await res.json();
        showMsg(d.error, "err");
      }
    } catch (e) {
      showMsg("Server nicht erreichbar", "err");
    }
  };

  // ── Select customer / load transactions ──
  const selectCustomer = async (customer) => {
    setSelected(customer);
    try {
      const res = await fetch(api(`/api/transactions?customer_id=${customer.id}`));
      if (!res.ok) throw new Error();
      setTransactions(await res.json());
    } catch (e) {
      setTransactions([]);
      showMsg("Verlauf konnte nicht geladen werden", "err");
    }
  };

  // ── Add a token to selected customer (Mami bekommt jetzt auch QR / neue Karte nach Verlust) ──
  const addTokenToSelected = async () => {
    if (!selected || !newTokenValue) return showMsg("Bitte Wert eingeben/scannen", "err");
    try {
      const res = await fetch(api(`/api/customers/${selected.id}/tokens`), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: newTokenType, value: newTokenValue }),
      });
      if (res.ok) {
        const updated = await res.json();
        setSelected(updated);
        setNewTokenValue("");
        showMsg("Zahlungsmittel hinzugefügt ✓");
        fetchCustomers();
      } else {
        const d = await res.json();
        showMsg(d.error, "err");
      }
    } catch (e) {
      showMsg("Server nicht erreichbar", "err");
    }
  };

  const deactivateToken = async (tokenId) => {
    if (!confirm("Dieses Zahlungsmittel deaktivieren? (z.B. weil Karte verloren ging)")) return;
    try {
      const res = await fetch(api(`/api/tokens/${tokenId}/deactivate`), { method: "POST" });
      if (res.ok) {
        const updated = await res.json();
        setSelected(updated);
        showMsg("Deaktiviert. Guthaben bleibt erhalten — neue Karte kann hinzugefügt werden.");
        fetchCustomers();
      } else {
        const d = await res.json().catch(() => ({}));
        showMsg(d.error || "Deaktivieren fehlgeschlagen", "err");
      }
    } catch (e) {
      showMsg("Server nicht erreichbar", "err");
    }
  };

  const reactivateToken = async (tokenId) => {
    try {
      const res = await fetch(api(`/api/tokens/${tokenId}/reactivate`), { method: "POST" });
      if (res.ok) {
        const updated = await res.json();
        setSelected(updated);
        showMsg("Wieder aktiviert ✓");
        fetchCustomers();
      } else {
        const d = await res.json().catch(() => ({}));
        showMsg(d.error || "Reaktivieren fehlgeschlagen", "err");
      }
    } catch (e) {
      showMsg("Server nicht erreichbar", "err");
    }
  };

  const deleteToken = async (tokenId) => {
    if (!confirm("Zahlungsmittel endgültig löschen?")) return;
    try {
      const res = await fetch(api(`/api/tokens/${tokenId}`), { method: "DELETE" });
      if (res.ok) {
        const updated = await res.json();
        setSelected(updated);
        fetchCustomers();
      } else {
        const d = await res.json().catch(() => ({}));
        showMsg(d.error || "Löschen fehlgeschlagen", "err");
      }
    } catch (e) {
      showMsg("Server nicht erreichbar", "err");
    }
  };

  // Fix Review #2: QR-Codes werden jetzt lokal mit der QrCode-Komponente gerendert,
  // kein externer Dienst (api.qrserver.com) mehr nötig — funktioniert auch ohne Internet.

  return (
    <div className={styles.page}>
      {/* Left: create + topup */}
      <div className={styles.col}>

        <div className={styles.card}>
          <h3>Neuen Kunden anlegen</h3>
          <div className={styles.field}>
            <label>Name</label>
            <input value={name} onChange={e => setName(e.target.value)} placeholder="z.B. Mami" />
          </div>

          <div className={styles.field}>
            <label>Zahlungsmittel</label>
            <div className={styles.modeSwitch}>
              <button className={`${styles.modeBtn} ${initType === "nfc" ? styles.modeActive : ""}`} onClick={() => setInitType("nfc")}>📡 NFC</button>
              <button className={`${styles.modeBtn} ${initType === "qr" ? styles.modeActive : ""}`} onClick={() => setInitType("qr")}>📷 QR</button>
              <button className={`${styles.modeBtn} ${initType === "both" ? styles.modeActive : ""}`} onClick={() => setInitType("both")}>💳 Beides</button>
              <button className={`${styles.modeBtn} ${initType === "none" ? styles.modeActive : ""}`} onClick={() => setInitType("none")}>— Später</button>
            </div>
          </div>

          {(initType === "nfc" || initType === "both") && (
            <div className={styles.field}>
              <label>📡 NFC-UID</label>
              <div className={styles.row}>
                <input value={initUid} onChange={e => setInitUid(e.target.value.toUpperCase())} placeholder="Karte scannen oder manuell" />
                <button className={styles.scanBtn} onClick={() => scanNfc("new-nfc")}>📡</button>
              </div>
            </div>
          )}

          {(initType === "qr" || initType === "both") && (
            <div className={styles.field}>
              <label>📷 QR-Code</label>
              <div className={styles.row}>
                <input value={initQr} onChange={e => setInitQr(e.target.value)} placeholder="QR scannen oder Text eingeben" />
                <button className={styles.scanBtn} onClick={() => scanQr("new-qr")}>📷</button>
                <button className={styles.scanBtn} onClick={() => genQrId(setInitQr)}>🎲</button>
              </div>
            </div>
          )}

          {initType === "none" && (
            <p className={styles.hint}>Kunde wird ohne Zahlungsmittel angelegt — kannst du später in der Detailansicht hinzufügen.</p>
          )}

          <div className={styles.field}>
            <label>Startguthaben (CHF)</label>
            <input type="number" value={balance} onChange={e => setBalance(e.target.value)} placeholder="0.00" min="0" step="0.50" />
          </div>
          <button className={styles.primaryBtn} onClick={createCustomer}>Kunde erstellen</button>
        </div>

        <div className={styles.card}>
          <h3>Guthaben aufladen</h3>
          <div className={styles.field}>
            <label>NFC, QR-Code oder Kunde wählen</label>
            <div className={styles.row}>
              <input value={topupId} onChange={e => setTopupId(e.target.value)} placeholder="NFC, QR-Code oder Kunden-ID …" />
              <button className={styles.scanBtn} onClick={() => scanNfc("topup")}>📡</button>
              <button className={styles.scanBtn} onClick={() => scanQr("topup")}>📷</button>
            </div>
          </div>
          <div className={styles.field}>
            <label>Betrag (CHF)</label>
            <div className={styles.row}>
              {[5, 10, 20].map(a => (
                <button key={a} className={styles.quickBtn} onClick={() => setTopupAmount(String(a))}>{a} CHF</button>
              ))}
              <input type="number" value={topupAmount} onChange={e => setTopupAmount(e.target.value)} placeholder="Betrag" min="0.50" step="0.50" style={{ flex: 1, minWidth: 70 }} />
            </div>
          </div>
          <button className={styles.primaryBtn} onClick={topup} disabled={!topupId || !topupAmount}>Aufladen</button>
        </div>

        {msg.text && (
          <div className={`${styles.toast} ${styles[msg.type === "err" ? "msgErr" : "msgOk"]} ${styles.show}`}>{msg.text}</div>
        )}
      </div>

      {/* Middle: customer list */}
      <div className={styles.col}>
        <div className={styles.card} style={{ flex: 1 }}>
          <div className={styles.listHeadRow}>
            <h3>Kunden ({customers.length})</h3>
            <button className={styles.overviewBtn} onClick={() => setShowOverview(true)}>📋 Übersicht</button>
          </div>
          <div className={styles.cardList}>
            {customers.length === 0 && <div className={styles.empty}>Noch keine Kunden</div>}
            {customers.map(c => (
              <div key={c.id}
                className={`${styles.cardRow} ${selected?.id === c.id ? styles.cardRowActive : ""}`}
                onClick={() => selectCustomer(c)}>
                <div className={styles.cardIcon}>👤</div>
                <div className={styles.cardInfo}>
                  <div className={styles.cardLabel}>{c.name}</div>
                  <div className={styles.cardMeta}>
                    {c.tokens.filter(t => t.active).map(t => (
                      <span key={t.id}>{t.type === "nfc" ? "📡" : "📷"} {t.value}</span>
                    ))}
                    {c.tokens.filter(t => t.active).length === 0 && <span className={styles.noToken}>kein Zahlungsmittel</span>}
                  </div>
                </div>
                <div className={`${styles.cardBalance} ${c.balance < 1 ? styles.balanceLow : ""}`}>{priceStr(c.balance)}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right: customer detail */}
      <div className={styles.col}>
        <div className={styles.card} style={{ flex: 1 }}>
          {!selected && (
            <>
              <h3>Details</h3>
              <div className={styles.empty}>Kunde auswählen</div>
            </>
          )}
          {selected && (
            <>
              <h3>{selected.name}</h3>

              <div className={styles.detailBalance}>{priceStr(selected.balance)}</div>

              {/* Tokens management */}
              <div className={styles.tokenSection}>
                <div className={styles.tokenSectionTitle}>Zahlungsmittel</div>
                {selected.tokens.length === 0 && <div className={styles.empty}>Noch keine</div>}
                {selected.tokens.map(t => (
                  <div key={t.id} className={`${styles.tokenRow} ${!t.active ? styles.tokenInactive : ""}`}>
                    <span>{t.type === "nfc" ? "📡" : "📷"}</span>
                    <span className={styles.tokenValue}>{t.value}</span>
                    {!t.active && <span className={styles.tokenBadge}>deaktiviert</span>}
                    {t.type === "qr" && t.active && (
                      <button className={styles.iconSmBtn} onClick={() => setShowQr(t)}>🖨️</button>
                    )}
                    {t.active
                      ? <button className={styles.iconSmBtn} onClick={() => deactivateToken(t.id)}>🚫</button>
                      : <button className={styles.iconSmBtn} onClick={() => reactivateToken(t.id)}>♻️</button>
                    }
                    <button className={styles.iconSmBtn} onClick={() => deleteToken(t.id)}>🗑️</button>
                  </div>
                ))}

                {/* Add new token */}
                <div className={styles.addTokenRow}>
                  <div className={styles.modeSwitch} style={{ marginBottom: 6 }}>
                    <button className={`${styles.modeBtn} ${newTokenType === "nfc" ? styles.modeActive : ""}`} onClick={() => setNewTokenType("nfc")}>📡 NFC</button>
                    <button className={`${styles.modeBtn} ${newTokenType === "qr" ? styles.modeActive : ""}`} onClick={() => setNewTokenType("qr")}>📷 QR</button>
                  </div>
                  <div className={styles.row}>
                    <input value={newTokenValue} onChange={e => setNewTokenValue(newTokenType === "nfc" ? e.target.value.toUpperCase() : e.target.value)} placeholder={newTokenType === "nfc" ? "Neue Karte scannen" : "QR-Wert"} />
                    <button className={styles.scanBtn} onClick={() => newTokenType === "nfc" ? scanNfc("add-token") : scanQr("add-token")}>
                      {newTokenType === "nfc" ? "📡" : "📷"}
                    </button>
                    {newTokenType === "qr" && (
                      <button className={styles.scanBtn} onClick={() => genQrId(setNewTokenValue)}>🎲</button>
                    )}
                  </div>
                  <button className={styles.primaryBtn} onClick={addTokenToSelected} style={{ marginTop: 6 }}>
                    + Hinzufügen
                  </button>
                </div>
              </div>

              {/* Transactions */}
              <div className={styles.tokenSectionTitle} style={{ marginTop: 10 }}>Verlauf</div>
              <div className={styles.cardList}>
                {transactions.length === 0 && <div className={styles.empty}>Keine Transaktionen</div>}
                {transactions.map(t => (
                  <div key={t.id} className={styles.txRow}>
                    <div>{t.type === "purchase" ? "🛒" : "💰"}</div>
                    <div className={styles.txNote}>{t.note}</div>
                    <div className={`${styles.txAmount} ${t.type === "purchase" ? styles.txMinus : styles.txPlus}`}>
                      {t.type === "purchase" ? "−" : "+"}{priceStr(t.amount)}
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </div>

      {/* Scan overlay */}
      {scanning && (
        <div className={styles.overlay}>
          <div className={styles.modal}>
            {scanning === "nfc"
              ? <><div className={styles.scanAnim}>🔵</div><p>NFC-Karte an die NFC-Box halten …</p></>
              : <></>}
            {scanning === "qr" && (
              <>
                <div className={styles.qrBox}>
                  <video ref={videoRef} className={styles.qrVideo} playsInline muted />
                  <div className={styles.qrFrame} />
                </div>
                <p>QR-Code vor die Kamera halten …</p>
              </>
            )}
            <button onClick={scanning === "nfc" ? stopNfcScan : stopQrScan}>Abbrechen</button>
          </div>
        </div>
      )}

      {/* Single QR display/print */}
      {showQr && (
        <div className={styles.overlay}>
          <div className={styles.modal}>
            <h3>{selected?.name}</h3>
            <QrCode value={showQr.value} size={200} />
            <p style={{ fontFamily: "monospace", fontSize: 13 }}>{showQr.value}</p>
            <button className={`${styles.primaryBtn} ${styles.noPrint}`} onClick={() => window.print()}>🖨️ Drucken</button>
            <button className={styles.noPrint} onClick={() => setShowQr(null)}>Schliessen</button>
          </div>
        </div>
      )}

      {/* Overview: all customers */}
      {showOverview && (
        <div className={styles.overlay} onClick={() => setShowOverview(false)}>
          <div className={styles.overviewModal} onClick={e => e.stopPropagation()}>
            <div className={styles.overviewHeader}>
              <h3>📋 Kundenübersicht</h3>
              <div className={styles.overviewActions}>
                <button className={styles.primaryBtn} onClick={() => window.print()}>🖨️ Alle drucken</button>
                <button className={styles.closeBtn} onClick={() => setShowOverview(false)}>✕</button>
              </div>
            </div>
            <div className={styles.overviewGrid}>
              {customers.length === 0 && <div className={styles.empty}>Noch keine Kunden</div>}
              {customers.map(c => {
                const qrToken = c.tokens.find(t => t.type === "qr" && t.active);
                const nfcTokens = c.tokens.filter(t => t.type === "nfc" && t.active);
                return (
                  <div key={c.id} className={styles.overviewCard}>
                    <div className={styles.overviewName}>{c.name}</div>
                    <div className={styles.overviewBalance}>{priceStr(c.balance)}</div>
                    {qrToken && <div className={styles.overviewQrImg}><QrCode value={qrToken.value} size={140} /></div>}
                    {nfcTokens.map(t => <div key={t.id} className={styles.overviewUid}>📡 {t.value}</div>)}
                    {qrToken && <div className={styles.overviewUid}>📷 {qrToken.value}</div>}
                    {!qrToken && nfcTokens.length === 0 && <div className={styles.overviewUid}>— keine Kennung —</div>}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
