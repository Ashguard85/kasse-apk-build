import React, { useEffect, useMemo, useRef, useState } from "react";
import styles from "./Einstellungen.module.css";
import {
  apiFetch,
  getApiBase,
  setApiBase,
  getCloudflareAccessConfig,
  setCloudflareAccessConfig,
  getDataMode,
  setDataMode,
  exportLocalData,
  importLocalData,
  resetLocalData,
} from "../lib/api";
import { DEFAULT_THEME } from "../lib/localDb";
import {
  THEME_PRESETS,
  applyAppearanceMode,
  getThemeChecks,
  getThemeRuntime,
  normalizeTheme,
} from "../lib/themePresets";
import { useProfile } from "../ProfileContext";
import { useCart } from "../CartContext";

const PAY_METHODS = [
  { id: "nfc", icon: "📡", label: "NFC", desc: "Web NFC direkt am Gerät" },
  { id: "qr", icon: "📷", label: "QR-Code", desc: "Kamera scannt den QR-Code" },
  { id: "bleNfc", icon: "🔵", label: "NFC-Box", desc: "Externe ESP32-Bluetooth-Box" },
  { id: "manual", icon: "✏️", label: "Name", desc: "Kundenname von Hand eingeben" },
];

const SIMPLE_THEME_FIELDS = [
  ["primaryColor", "Hauptfarbe"],
  ["accentColor", "Akzentfarbe"],
  ["pageBackground", "Seitenhintergrund"],
  ["registerBackground", "Kassenhintergrund"],
  ["bannerBackground", "Bannerfarbe"],
];

function readImageFile(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error("Bild konnte nicht gelesen werden"));
    reader.readAsDataURL(file);
  });
}

export default function Einstellungen() {
  const { profiles, activeProfile, refreshProfiles, switchProfile } = useProfile();
  const { cart, clearCart } = useCart();
  const [enabled, setEnabled] = useState({ nfc: true, qr: true, bleNfc: true, manual: true });
  const [defaultMode, setDefaultMode] = useState("nfc");
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState({ text: "", type: "" });
  const [serverUrl, setServerUrl] = useState(getApiBase());
  const [dataMode, setDataModeState] = useState(getDataMode());
  const initialAccess = getCloudflareAccessConfig();
  const [cfClientId, setCfClientId] = useState(initialAccess.clientId);
  const [cfClientSecret, setCfClientSecret] = useState(initialAccess.clientSecret);
  const [cfSecretHidden, setCfSecretHidden] = useState(Boolean(initialAccess.clientSecret));
  const [newProfileName, setNewProfileName] = useState("");
  const [profileName, setProfileName] = useState("");
  const [theme, setTheme] = useState(() => normalizeTheme(DEFAULT_THEME));
  const msgTimerRef = useRef(null);
  const importFileRef = useRef(null);
  const bannerFileRef = useRef(null);
  const logoFileRef = useRef(null);

  const preview = useMemo(() => getThemeRuntime({ ...DEFAULT_THEME, ...theme }), [theme]);
  const contrastChecks = useMemo(() => getThemeChecks({ ...DEFAULT_THEME, ...theme }), [theme]);

  const showMsg = (text, type = "ok") => {
    if (msgTimerRef.current) clearTimeout(msgTimerRef.current);
    setMsg({ text, type });
    msgTimerRef.current = setTimeout(() => setMsg({ text: "", type: "" }), 3800);
  };

  const updateTheme = (patch) => {
    setTheme((current) => normalizeTheme({ ...current, ...patch }));
  };

  const loadPaymentSettings = async () => {
    setLoading(true);
    try {
      const res = await apiFetch("/api/settings/payment");
      if (!res.ok) throw new Error();
      const data = await res.json();
      setEnabled(data.enabled);
      setDefaultMode(data.default);
      try { localStorage.setItem("kasseBleNfcEnabled", data.enabled?.bleNfc ? "1" : "0"); } catch {}
      window.dispatchEvent(new CustomEvent("kasse:payment-settings-updated", { detail: data }));
    } catch {
      showMsg("Einstellungen konnten nicht geladen werden", "err");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (activeProfile) {
      setProfileName(activeProfile.name);
      setTheme(normalizeTheme({ ...DEFAULT_THEME, ...(activeProfile.theme || {}) }));
      loadPaymentSettings();
    }
  }, [activeProfile?.id]);

  useEffect(() => () => {
    if (msgTimerRef.current) clearTimeout(msgTimerRef.current);
  }, []);

  const selectProfile = async (id) => {
    if (Number(id) === Number(activeProfile?.id)) return;
    if (cart.length && !confirm("Beim Profilwechsel wird der aktuelle Warenkorb geleert. Profil wechseln?")) return;
    clearCart();
    await switchProfile(Number(id));
    showMsg("Profil gewechselt ✓");
  };

  const createProfile = async () => {
    const name = newProfileName.trim();
    if (!name) return showMsg("Bitte einen Profilnamen eingeben", "err");
    try {
      const res = await apiFetch("/api/profiles", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, theme: normalizeTheme({ ...DEFAULT_THEME, bannerText: name }) }),
      });
      const data = await res.json();
      if (!res.ok) return showMsg(data.error || "Profil konnte nicht erstellt werden", "err");
      setNewProfileName("");
      await refreshProfiles();
      clearCart();
      await switchProfile(data.id);
      showMsg(`Profil „${data.name}“ erstellt ✓`);
    } catch {
      showMsg("Profil konnte nicht erstellt werden", "err");
    }
  };

  const saveProfile = async () => {
    if (!activeProfile) return;
    try {
      const cleanTheme = normalizeTheme(theme);
      const res = await apiFetch(`/api/profiles/${activeProfile.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: profileName, theme: cleanTheme }),
      });
      const data = await res.json();
      if (!res.ok) return showMsg(data.error || "Profil konnte nicht gespeichert werden", "err");
      await refreshProfiles();
      window.dispatchEvent(new CustomEvent("kasse:profiles-updated"));
      showMsg("Profil und Design gespeichert ✓");
    } catch {
      showMsg("Profil konnte nicht gespeichert werden", "err");
    }
  };

  const setProfileActive = async (profile, active) => {
    if (!active && Number(profile.id) === Number(activeProfile?.id)
      && !confirm("Aktives Profil archivieren? Danach wird auf ein anderes Profil gewechselt.")) return;
    try {
      const res = await apiFetch(`/api/profiles/${profile.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ active }),
      });
      const data = await res.json();
      if (!res.ok) return showMsg(data.error || "Änderung fehlgeschlagen", "err");
      const rows = await refreshProfiles();
      if (!active && Number(profile.id) === Number(activeProfile?.id)) {
        const next = rows.find((item) => item.active && Number(item.id) !== Number(profile.id));
        if (next) {
          clearCart();
          await switchProfile(next.id);
        }
      }
      showMsg(active ? "Profil reaktiviert ✓" : "Profil archiviert ✓");
    } catch {
      showMsg("Änderung fehlgeschlagen", "err");
    }
  };

  const applyPreset = (preset) => {
    setTheme((current) => normalizeTheme({
      ...current,
      ...preset.theme,
      bannerText: current.bannerText,
      bannerImageDataUrl: current.bannerImageDataUrl,
      logoImageDataUrl: current.logoImageDataUrl,
    }));
    showMsg(`Vorlage „${preset.name}“ übernommen`);
  };

  const loadThemeImage = async (event, key, label) => {
    const file = event.target.files?.[0];
    if (!file) return;
    try {
      const data = await readImageFile(file);
      updateTheme({ [key]: data });
      showMsg(`${label} geladen ✓`);
    } catch {
      showMsg(`${label} konnte nicht geladen werden`, "err");
    } finally {
      event.target.value = "";
    }
  };

  const toggleMethod = (id) => setEnabled((previous) => {
    const next = { ...previous, [id]: !previous[id] };
    if (!next[id] && defaultMode === id) {
      const first = PAY_METHODS.map((method) => method.id).find((method) => next[method]);
      if (first) setDefaultMode(first);
    }
    return next;
  });

  const activeCount = Object.values(enabled).filter(Boolean).length;

  const savePayments = async () => {
    if (!activeCount || !enabled[defaultMode]) return showMsg("Mindestens eine aktive Methode mit aktivem Standard ist nötig", "err");
    try {
      const res = await apiFetch("/api/settings/payment", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ enabled, default: defaultMode }),
      });
      const data = await res.json();
      if (!res.ok) return showMsg(data.error || "Speichern fehlgeschlagen", "err");
      setEnabled(data.enabled);
      setDefaultMode(data.default);
      window.dispatchEvent(new CustomEvent("kasse:payment-settings-updated", { detail: data }));
      showMsg("Zahlungsmethoden gespeichert ✓");
    } catch {
      showMsg("Speichern fehlgeschlagen", "err");
    }
  };

  const changeDataMode = async (mode) => {
    const next = setDataMode(mode);
    setDataModeState(next);
    await refreshProfiles().catch(() => {});
    showMsg(next === "local" ? "Lokaler Datenmodus aktiv" : "Servermodus aktiv");
  };

  const exportBackup = () => {
    try {
      const blob = new Blob([exportLocalData()], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = `kasse-backup-${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      URL.revokeObjectURL(url);
      showMsg("Backup exportiert ✓");
    } catch {
      showMsg("Backup konnte nicht exportiert werden", "err");
    }
  };

  const importBackup = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    try {
      importLocalData(await file.text());
      await refreshProfiles();
      await loadPaymentSettings();
      showMsg("Backup importiert ✓");
    } catch {
      showMsg("Backup konnte nicht importiert werden", "err");
    } finally {
      event.target.value = "";
    }
  };

  const resetLocalBackup = async () => {
    if (!confirm("Lokale Daten wirklich zurücksetzen?")) return;
    resetLocalData();
    await refreshProfiles();
    await loadPaymentSettings();
    showMsg("Lokale Daten zurückgesetzt");
  };

  const saveCloudflareAccess = () => {
    setCloudflareAccessConfig({ clientId: cfClientId, clientSecret: cfClientSecret });
    setCfSecretHidden(Boolean(cfClientSecret));
    showMsg("Cloudflare-Daten gespeichert");
  };

  const testConnection = async () => {
    try {
      const res = await apiFetch("/api/status");
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      showMsg(`Verbindung funktioniert – ${data.profile?.name || "Profil"} ✓`);
    } catch (error) {
      showMsg(`Server nicht erreichbar: ${error.message || "Verbindungsfehler"}`, "err");
    }
  };

  const cfSecretDisplayValue = cfSecretHidden && cfClientSecret ? "••••••••••••••••" : cfClientSecret;

  return (
    <div className={styles.page}>
      <div className={styles.card}>
        <h1 className={styles.title}>⚙️ Einstellungen</h1>
        <p className={styles.intro}>Profilwechsel, Design, Zahlungsmethoden und Verbindungseinstellungen.</p>

        <h2 className={styles.sectionTitle}>🏪 Aktives Profil</h2>
        <div className={styles.serverBox}>
          <div className={styles.profileSwitchRow}>
            <label>
              Profil
              <select value={activeProfile?.id || ""} onChange={(event) => selectProfile(event.target.value)}>
                {profiles.filter((profile) => profile.active).map((profile) => (
                  <option key={profile.id} value={profile.id}>{profile.name}</option>
                ))}
              </select>
            </label>
            <span>Der Profilwechsel ist nur hier möglich.</span>
          </div>
          <div className={styles.profileCreateRow}>
            <input
              value={newProfileName}
              onChange={(event) => setNewProfileName(event.target.value)}
              placeholder="Neues Profil, z.B. Nagelstudio"
            />
            <button onClick={createProfile}>+ Profil erstellen</button>
          </div>
          {profiles.some((profile) => !profile.active) && (
            <div className={styles.archiveList}>
              {profiles.filter((profile) => !profile.active).map((profile) => (
                <div key={profile.id}>
                  <span>{profile.name}</span>
                  <button className={styles.secondaryBtn} onClick={() => setProfileActive(profile, true)}>Reaktivieren</button>
                </div>
              ))}
            </div>
          )}
        </div>

        {activeProfile && (
          <>
            <h2 className={styles.sectionTitle}>🎨 Profil und App-Design</h2>
            <div className={styles.serverBox}>
              <label className={styles.profileNameField}>
                Profilname
                <input value={profileName} onChange={(event) => setProfileName(event.target.value)} />
              </label>
              <label className={styles.profileNameField}>
                Bannertext
                <input
                  value={theme.bannerText || ""}
                  onChange={(event) => updateTheme({ bannerText: event.target.value })}
                  placeholder="Willkommen im Einkaufsladen"
                />
              </label>

              <h3 className={styles.subTitle}>Designvorlagen</h3>
              <p className={styles.helpText}>Eine Vorlage setzt nur Farben und Darstellungsmodus. Eigene Bilder und Texte bleiben erhalten.</p>
              <div className={styles.presetGrid}>
                {THEME_PRESETS.map((preset) => (
                  <button key={preset.id} className={styles.presetCard} onClick={() => applyPreset(preset)}>
                    <span className={styles.presetHeading}><b>{preset.icon} {preset.name}</b><small>{preset.description}</small></span>
                    <span className={styles.swatches}>
                      <i style={{ background: preset.theme.primaryColor }} />
                      <i style={{ background: preset.theme.accentColor }} />
                      <i style={{ background: preset.theme.pageBackground }} />
                    </span>
                  </button>
                ))}
              </div>

              <div className={styles.modeEditor}>
                <div>
                  <h3 className={styles.subTitle}>Darstellung</h3>
                  <p className={styles.helpText}>Hell eignet sich für die meisten Tablets. Dunkel ist für gedämpfte Umgebungen gedacht.</p>
                </div>
                <div className={styles.modeButtons}>
                  <button
                    className={theme.appearanceMode !== "dark" ? styles.modeButtonActive : ""}
                    onClick={() => setTheme(applyAppearanceMode(theme, "light"))}
                  >☀️ Hell</button>
                  <button
                    className={theme.appearanceMode === "dark" ? styles.modeButtonActive : ""}
                    onClick={() => setTheme(applyAppearanceMode(theme, "dark"))}
                  >🌙 Dunkel</button>
                </div>
              </div>

              <label className={styles.autoContrastRow}>
                <input
                  type="checkbox"
                  checked={theme.autoContrast !== false}
                  onChange={(event) => updateTheme({ autoContrast: event.target.checked })}
                />
                <span><strong>Farben automatisch lesbar halten</strong><small>Textfarben und dunkle Buttonfarbe werden automatisch berechnet.</small></span>
              </label>

              <div className={styles.colorGrid}>
                {SIMPLE_THEME_FIELDS.map(([key, label]) => (
                  <label key={key}>
                    {label}
                    <span>
                      <input
                        type="color"
                        value={theme[key] || DEFAULT_THEME[key]}
                        onChange={(event) => updateTheme({ [key]: event.target.value })}
                      />
                      <code>{theme[key]}</code>
                    </span>
                  </label>
                ))}
              </div>

              {theme.autoContrast === false && (
                <details className={styles.advancedColors}>
                  <summary>Erweiterte Textfarben</summary>
                  <div className={styles.colorGrid}>
                    <label>
                      Dunkle Hauptfarbe
                      <span><input type="color" value={theme.primaryDark} onChange={(event) => updateTheme({ primaryDark: event.target.value })} /><code>{theme.primaryDark}</code></span>
                    </label>
                    <label>
                      Banner-Textfarbe
                      <span><input type="color" value={theme.bannerTextColor} onChange={(event) => updateTheme({ bannerTextColor: event.target.value })} /><code>{theme.bannerTextColor}</code></span>
                    </label>
                  </div>
                </details>
              )}

              <div className={styles.imageEditor}>
                <div>
                  <h3 className={styles.subTitle}>Logo und Bannerbild</h3>
                  <p className={styles.helpText}>Das Logo wird links im Kassenbanner angezeigt. Ein ruhiges, breites Bannerbild funktioniert am besten.</p>
                </div>
                <div className={styles.serverActions}>
                  <button onClick={() => logoFileRef.current?.click()}>Logo wählen</button>
                  <button className={styles.secondaryBtn} onClick={() => updateTheme({ logoImageDataUrl: "" })}>Logo entfernen</button>
                  <button onClick={() => bannerFileRef.current?.click()}>Bannerbild wählen</button>
                  <button className={styles.secondaryBtn} onClick={() => updateTheme({ bannerImageDataUrl: "" })}>Banner entfernen</button>
                </div>
                <input ref={logoFileRef} type="file" accept="image/*" hidden onChange={(event) => loadThemeImage(event, "logoImageDataUrl", "Logo")} />
                <input ref={bannerFileRef} type="file" accept="image/*" hidden onChange={(event) => loadThemeImage(event, "bannerImageDataUrl", "Bannerbild")} />
              </div>

              <h3 className={styles.subTitle}>Live-Vorschau</h3>
              <div className={styles.appPreview} style={{ background: preview.pageBackground, color: preview.palette.gray800 }}>
                <div className={styles.previewNav} style={{ background: preview.primaryColor, color: preview.primaryText }}>
                  <b>🛒 KinderKasse</b>
                  <span style={{ background: preview.accentColor, color: preview.accentText }}>Kasse</span>
                  <span>Produkte</span>
                  <span>Einstellungen</span>
                </div>
                <div className={styles.previewRegister} style={{ background: preview.registerBackground }}>
                  <div
                    className={styles.bannerPreview}
                    style={{
                      backgroundColor: preview.bannerBackground,
                      color: theme.bannerImageDataUrl ? "#ffffff" : preview.bannerTextColor,
                      backgroundImage: theme.bannerImageDataUrl
                        ? `linear-gradient(rgba(0,0,0,.38),rgba(0,0,0,.38)),url(${theme.bannerImageDataUrl})`
                        : "none",
                    }}
                  >
                    {theme.logoImageDataUrl && <img src={theme.logoImageDataUrl} alt="Profil-Logo" />}
                    <span><strong>{profileName || activeProfile.name}</strong><small>{theme.bannerText}</small></span>
                  </div>
                  <div className={styles.previewContent}>
                    <div className={styles.previewProducts}>
                      {["Nagellack", "Maniküre", "Pflege"].map((item, index) => (
                        <div key={item} style={{ background: preview.surface, color: preview.palette.gray800 }}>
                          <b>{["💅", "✨", "🧴"][index]}</b><span>{item}</span>
                        </div>
                      ))}
                    </div>
                    <div className={styles.previewCart} style={{ background: preview.surface, color: preview.palette.gray800 }}>
                      <strong>Warenkorb</strong><span>Maniküre · 25.00 CHF</span>
                      <button style={{ background: preview.primaryColor, color: preview.primaryText }}>Bezahlen</button>
                    </div>
                  </div>
                </div>
              </div>

              <div className={styles.contrastGrid}>
                {contrastChecks.map((check) => {
                  const passed = check.ratio >= 4.5;
                  return (
                    <div key={check.id} className={passed ? styles.contrastOk : styles.contrastWarn}>
                      <span>{passed ? "✓" : "!"}</span>
                      <div><strong>{check.label}</strong><small>Kontrast {check.ratio.toFixed(1)}:1</small></div>
                    </div>
                  );
                })}
              </div>

              <div className={styles.serverActions}>
                <button onClick={saveProfile}>Profil und Design speichern</button>
                <button
                  className={styles.secondaryBtn}
                  onClick={() => setTheme(normalizeTheme({ ...DEFAULT_THEME, bannerText: profileName || activeProfile.name }))}
                >Standardfarben</button>
                {profiles.filter((profile) => profile.active).length > 1 && (
                  <button className={styles.dangerBtn} onClick={() => setProfileActive(activeProfile, false)}>Profil archivieren</button>
                )}
              </div>
            </div>
          </>
        )}

        <div className={styles.settingsDivider} />
        <h2 className={styles.sectionTitle}>💳 Zahlungsmethoden dieses Profils</h2>
        <div className={styles.methodList}>
          {PAY_METHODS.map((method) => (
            <div key={method.id} className={`${styles.methodRow} ${enabled[method.id] ? "" : styles.methodOff}`}>
              <div className={styles.methodIcon}>{method.icon}</div>
              <div className={styles.methodInfo}>
                <div className={styles.methodLabel}>{method.label}</div>
                <div className={styles.methodDesc}>{method.desc}</div>
              </div>
              <div className={styles.methodControls}>
                <button
                  className={`${styles.defaultBtn} ${defaultMode === method.id ? styles.defaultActive : ""}`}
                  onClick={() => enabled[method.id] && setDefaultMode(method.id)}
                  disabled={!enabled[method.id]}
                >{defaultMode === method.id ? "★ Standard" : "Standard"}</button>
                <button className={`${styles.toggle} ${enabled[method.id] ? styles.toggleOn : styles.toggleOff}`} onClick={() => toggleMethod(method.id)}>
                  <span className={styles.toggleKnob} />
                </button>
              </div>
            </div>
          ))}
        </div>
        <button className={styles.saveBtn} onClick={savePayments} disabled={!activeCount || loading}>Zahlungsmethoden speichern</button>

        <div className={styles.settingsDivider} />
        <h2 className={styles.sectionTitle}>💾 Daten speichern</h2>
        <div className={styles.serverBox}>
          <h2>{dataMode === "local" ? "📱 Lokal auf diesem Tablet" : "🌐 Server / Docker"}</h2>
          <p>Auch im Lokalmodus sind Profile, Produkte, Bons und Guthaben getrennt.</p>
          <div className={styles.modeChoice}>
            <button className={`${styles.modeChoiceBtn} ${dataMode === "local" ? styles.modeChoiceActive : ""}`} onClick={() => changeDataMode("local")}>📱 Lokal speichern<span>offline ohne Server</span></button>
            <button className={`${styles.modeChoiceBtn} ${dataMode === "server" ? styles.modeChoiceActive : ""}`} onClick={() => changeDataMode("server")}>🌐 Server verwenden<span>Docker/NAS/Cloudflare</span></button>
          </div>
          {dataMode === "local" && (
            <div className={styles.localTools}>
              <div className={styles.serverActions}>
                <button onClick={exportBackup}>Backup exportieren</button>
                <button className={styles.secondaryBtn} onClick={() => importFileRef.current?.click()}>Backup importieren</button>
                <button className={styles.dangerBtn} onClick={resetLocalBackup}>Lokal zurücksetzen</button>
              </div>
              <input ref={importFileRef} type="file" accept="application/json,.json" hidden onChange={importBackup} />
            </div>
          )}
        </div>

        {dataMode === "server" && (
          <>
            <div className={styles.settingsDivider} />
            <h2 className={styles.sectionTitle}>🔧 Server</h2>
            <div className={styles.serverBox}>
              <h2>🔗 Server-Verbindung</h2>
              <div className={styles.serverRow}>
                <input value={serverUrl} onChange={(event) => setServerUrl(event.target.value)} placeholder="https://kasse.example.ch oder http://192.168.1.50:3800" />
                <button onClick={() => { setApiBase(serverUrl); showMsg("Server-Adresse gespeichert"); }}>Speichern</button>
                <button onClick={testConnection}>Test</button>
              </div>
            </div>
            <div className={styles.serverBox}>
              <h2>☁️ Cloudflare Access</h2>
              <div className={styles.tokenGrid}>
                <label>Client ID<input value={cfClientId} onChange={(event) => setCfClientId(event.target.value)} /></label>
                <label>Client Secret<input value={cfSecretDisplayValue} onFocus={() => { if (cfSecretHidden) { setCfClientSecret(""); setCfSecretHidden(false); } }} onChange={(event) => setCfClientSecret(event.target.value)} type="text" /></label>
              </div>
              <div className={styles.serverActions}>
                <button onClick={saveCloudflareAccess}>Cloudflare-Daten speichern</button>
                <button className={styles.secondaryBtn} onClick={() => { setCfClientId(""); setCfClientSecret(""); setCfSecretHidden(false); setCloudflareAccessConfig({}); }}>Löschen</button>
              </div>
            </div>
          </>
        )}

        {msg.text && <div className={`${styles.msg} ${msg.type === "err" ? styles.msgErr : styles.msgOk}`}>{msg.text}</div>}
      </div>
    </div>
  );
}
