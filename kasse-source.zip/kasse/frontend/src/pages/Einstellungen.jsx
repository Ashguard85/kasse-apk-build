import React, { useState, useEffect, useRef } from "react";
import styles from "./Einstellungen.module.css";
import { api, getApiBase, setApiBase } from "../lib/api";

// Anzeige-Infos für die vier Zahlungsmethoden
const PAY_METHODS = [
  { id: "nfc", icon: "📡", label: "NFC", desc: "Web NFC direkt am Gerät (nur Geräte mit eingebautem NFC)" },
  { id: "qr", icon: "📷", label: "QR-Code", desc: "Kamera scannt den QR-Code der Karte" },
  { id: "bleNfc", icon: "🔵", label: "NFC-Box", desc: "Externe ESP32-Bluetooth-Box (für Geräte ohne NFC)" },
  { id: "manual", icon: "✏️", label: "Name", desc: "Kundenname von Hand eintippen" },
];

export default function Einstellungen() {
  const [enabled, setEnabled] = useState({ nfc: true, qr: true, bleNfc: true, manual: true });
  const [defaultMode, setDefaultMode] = useState("nfc");
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState({ text: "", type: "" });
  const [serverUrl, setServerUrl] = useState(getApiBase());
  const msgTimerRef = useRef(null);

  const showMsg = (text, type = "ok") => {
    if (msgTimerRef.current) clearTimeout(msgTimerRef.current);
    setMsg({ text, type });
    msgTimerRef.current = setTimeout(() => setMsg({ text: "", type: "" }), 3000);
  };

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch(api(`/api/settings/payment`));
        if (!res.ok) throw new Error("Server-Fehler");
        const data = await res.json();
        setEnabled(data.enabled);
        setDefaultMode(data.default);
      } catch (e) {
        showMsg("Einstellungen konnten nicht geladen werden", "err");
      } finally {
        setLoading(false);
      }
    })();
    return () => { if (msgTimerRef.current) clearTimeout(msgTimerRef.current); };
  }, []);

  const toggleMethod = (id) => {
    setEnabled((prev) => {
      const next = { ...prev, [id]: !prev[id] };
      // Wenn die gerade deaktivierte Methode der Standard war, Standard auf
      // die erste noch aktive Methode verschieben.
      if (!next[id] && defaultMode === id) {
        const firstActive = PAY_METHODS.map((m) => m.id).find((m) => next[m]);
        if (firstActive) setDefaultMode(firstActive);
      }
      return next;
    });
  };

  const activeCount = Object.values(enabled).filter(Boolean).length;


  const saveServerUrl = () => {
    setApiBase(serverUrl);
    showMsg("Server-Adresse gespeichert. App bei Bedarf neu öffnen.");
  };

  const save = async () => {
    if (activeCount === 0) {
      return showMsg("Mindestens eine Methode muss aktiv sein", "err");
    }
    if (!enabled[defaultMode]) {
      return showMsg("Die Standard-Methode muss aktiviert sein", "err");
    }
    try {
      const res = await fetch(api(`/api/settings/payment`), {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ enabled, default: defaultMode }),
      });
      const data = await res.json();
      if (res.ok) {
        setEnabled(data.enabled);
        setDefaultMode(data.default);
        showMsg("Einstellungen gespeichert ✓");
      } else {
        showMsg(data.error || "Speichern fehlgeschlagen", "err");
      }
    } catch (e) {
      showMsg("Server nicht erreichbar", "err");
    }
  };

  return (
    <div className={styles.page}>
      <div className={styles.card}>
        <h1 className={styles.title}>⚙️ Zahlungsmethoden</h1>
        <p className={styles.intro}>
          Lege fest, welche Zahlungsmethoden in der Kasse angezeigt werden und
          welche beim Öffnen vorausgewählt ist. Diese Einstellung gilt für alle Geräte.
        </p>


        <div className={styles.serverBox}>
          <h2>🔗 Server-Verbindung</h2>
          <p>In der APK hier die Adresse deiner Kasse eintragen, z.B. <b>https://deine-domain</b> oder <b>http://192.168.1.50:3800</b>. Im Browser leer lassen.</p>
          <div className={styles.serverRow}>
            <input
              value={serverUrl}
              onChange={(e) => setServerUrl(e.target.value)}
              placeholder="Server-Adresse, z.B. https://kasse.example.ch"
            />
            <button onClick={saveServerUrl}>Speichern</button>
          </div>
        </div>

        <div className={styles.methodList}>
          {PAY_METHODS.map((m) => (
            <div key={m.id} className={`${styles.methodRow} ${enabled[m.id] ? "" : styles.methodOff}`}>
              <div className={styles.methodIcon}>{m.icon}</div>
              <div className={styles.methodInfo}>
                <div className={styles.methodLabel}>{m.label}</div>
                <div className={styles.methodDesc}>{m.desc}</div>
              </div>
              <div className={styles.methodControls}>
                {/* Standard-Markierung: nur wählbar, wenn aktiv */}
                <button
                  className={`${styles.defaultBtn} ${defaultMode === m.id ? styles.defaultActive : ""}`}
                  onClick={() => enabled[m.id] && setDefaultMode(m.id)}
                  disabled={!enabled[m.id]}
                  title="Als Standard setzen"
                >
                  {defaultMode === m.id ? "★ Standard" : "Standard"}
                </button>
                {/* An/Aus-Schalter */}
                <button
                  className={`${styles.toggle} ${enabled[m.id] ? styles.toggleOn : styles.toggleOff}`}
                  onClick={() => toggleMethod(m.id)}
                  title={enabled[m.id] ? "Deaktivieren" : "Aktivieren"}
                >
                  <span className={styles.toggleKnob} />
                </button>
              </div>
            </div>
          ))}
        </div>

        {activeCount === 0 && (
          <p className={styles.warn}>⚠️ Mindestens eine Methode muss aktiv sein.</p>
        )}

        <button className={styles.saveBtn} onClick={save} disabled={activeCount === 0}>
          Speichern
        </button>

        {msg.text && (
          <div className={`${styles.msg} ${msg.type === "err" ? styles.msgErr : styles.msgOk}`}>
            {msg.text}
          </div>
        )}
      </div>
    </div>
  );
}
