# 🛒 Kinder-Kasse

Eine spielerische Supermarkt-Kassen-App für Tablets mit NFC- und QR-Bezahlung.

## Schnellstart

```bash
mkdir -p /home/buebi/docker/kasse/data/uploads
docker compose up --build
```

Dann im Browser (Chrome auf Android): **http://deine-ip:3800**

---

## Was die App kann

| Bereich | Funktion |
|---------|----------|
| **Kasse** | Artikel antippen → Warenkorb → mit NFC oder QR-Code bezahlen |
| **Kunden** | Kunden anlegen, mehrere NFC-Karten/QR-Codes pro Kunde verwalten, Guthaben aufladen, Verlauf sehen |
| **Artikel** | Artikel verwalten mit Bild, Name und Preis |

---

## NFC-Bezahlung

Die App nutzt die **Web NFC API** – das funktioniert nur mit:
- **Chrome auf Android** (kein Desktop, kein Firefox, kein Safari, kein iOS)
- Ein Tablet mit **eingebautem NFC-Chip** (viele günstige Tablets, darunter das Lenovo Tab M11, haben **kein NFC**!)
- NFC muss im Android-System aktiviert sein
- **Sicherer Kontext (HTTPS)** ist zwingend erforderlich — siehe Abschnitt unten

**Drei Zahlungsmodi stehen zur Auswahl:**
1. **📡 NFC** — Web NFC API, nur wenn das Tablet selbst NFC-Hardware hat
2. **📷 QR-Code** — funktioniert auf jedem Gerät mit Kamera, kein NFC-Chip nötig
3. **🔵 NFC-Box** — externe ESP32+PN532-Bluetooth-Bridge für Tablets ohne NFC (siehe `esp32-nfc-bridge/README.md`)

**So funktioniert der Ablauf:**
1. Kunde in der App anlegen (Kunden-Seite → NFC oder QR scannen)
2. Guthaben aufladen
3. In der Kasse: Artikel in den Warenkorb → Zahlungsmodus wählen → Karte/Code/NFC-Box verwenden

---

## 🔵 Kein NFC im Tablet? → ESP32-Bridge

Viele günstige Android-Tablets (z.B. **Lenovo Tab M11**) haben trotz Android **keinen
NFC-Chip** eingebaut. Für rund 15–25 CHF lässt sich das mit einem ESP32 +
PN532-Modul nachrüsten — die Anleitung samt Firmware liegt im Ordner
`esp32-nfc-bridge/`. Das Gerät verbindet sich per **Web Bluetooth** mit der App
(Modus "🔵 NFC-Box") und funktioniert technisch wie ein externer Kartenleser.

---

## ⚠️ Wichtig: NFC, QR-Kamera und Bluetooth-Bridge brauchen alle HTTPS

Web NFC, `getUserMedia()` (Kamera für QR-Scan) und Web Bluetooth (für die ESP32-Bridge) funktionieren **nur in einem sicheren Kontext** (HTTPS oder `localhost`). Reines `http://192.168.x.x:3800` im Heimnetz reicht für **keine dieser drei Methoden** aus.

Optionen:
- **Cloudflare Tunnel** (empfohlen, siehe vorheriger Chatverlauf) — echtes HTTPS ohne offene Ports
- Eigenes Reverse-Proxy-Setup mit TLS-Zertifikat

Ohne HTTPS bleibt nur: NFC-UID oder QR-Wert **manuell eintippen** statt scannen — das funktioniert auch über einfaches HTTP, da dabei kein `getUserMedia`, `NDEFReader` oder `navigator.bluetooth` aufgerufen wird.

---

## Ports

| Service | Port |
|---------|------|
| Frontend (Web-App) | 3800 |
| Backend (API) | 3801 |

---

## Datenpersistenz

Die SQLite-Datenbank und Bilder werden unter `/home/buebi/docker/kasse/data` auf dem Host gespeichert (fester Pfad, kein anonymes Docker-Volume).

Backup:
```bash
cp /home/buebi/docker/kasse/data/kasse.db ./kasse-backup-$(date +%Y%m%d).db
```

Zum Zurücksetzen einfach den Ordnerinhalt löschen (Container müssen dafür gestoppt sein):
```bash
docker compose down
rm -rf /home/buebi/docker/kasse/data/*
docker compose up
```

---

## 🍏 Hinweise für Safari / iOS

**QR-Code-Scannen funktioniert auf Safari/iOS in der Praxis nicht zuverlässig.** Der Code verlangt die `BarcodeDetector`-API, die auf iOS Safari nicht oder nur experimentell verfügbar ist. Konkret bedeutet das:

- **Scannen per Kamera:** funktioniert zuverlässig nur in **Chrome auf Android**. Auf Safari/iOS kommt die Fehlermeldung "QR-Scan auf diesem Gerät nicht verfügbar".
- **Workaround für Safari/iOS:** den NFC-UID- oder QR-Wert manuell ins Textfeld eintippen statt zu scannen — das geht überall, unabhängig vom Browser.
- Zusätzlich gilt für die Kamera generell: HTTPS ist zwingend, und die App darf **nicht als installierte PWA** (Standalone-Modus) laufen — WebKit hat einen bekannten Bug, der `getUserMedia()` dort blockiert. Im normalen Safari-Browser mit sichtbarer Adressleiste ist die Chance höher, dass die Kamera überhaupt startet — auch wenn das eigentliche QR-Decoding danach trotzdem an `BarcodeDetector` scheitert.
- NFC funktioniert auf iOS **grundsätzlich nicht** über Safari, unabhängig von HTTPS — das ist eine reine Plattform-Einschränkung von Apple. Nur Chrome auf Android unterstützt Web NFC.

**Kurz gesagt:** für Geräte ausserhalb von Chrome/Android ist die manuelle Eingabe der verlässliche Weg, nicht das Scannen.

---

## 🔐 Cloudflare Access (Zero Trust) und PWA

Falls für die Domain eine **Cloudflare Access Policy** (Login-Schutz) aktiv ist:
auf dem Tablet einmal einloggen, dann hält Cloudflare die Session normalerweise
für eine gewisse Zeit (je nach Policy-Einstellung). Der Service Worker
(`sw.js`) ist so gebaut, dass er Access-Login-Redirects nicht mehr abfängt
oder zum Absturz bringt — vorher führte das dazu, dass Artikelbilder als 404
erschienen, obwohl sie auf dem Server vorhanden waren.

**App-Installation (Chrome "App installieren" statt nur "Zur Startseite
hinzufügen"):** das Manifest wird jetzt mit `crossorigin="use-credentials"`
geladen (`index.html`), damit Chrome das Cloudflare-Access-Cookie beim
Manifest-Request mitschickt. Ohne das bekommt Chrome statt dem echten JSON
die Cloudflare-Login-Seite zurück und erkennt die App nicht als
installierbare PWA.

**Falls die Installation trotzdem nicht klappt:** direkt auf dem Tablet im
Browser folgende URLs öffnen und prüfen, ob wirklich JSON/JS-Code kommt statt
einer Login-Seite oder Fehlerseite:
```
https://deine-domain/manifest.json
https://deine-domain/sw.js
https://deine-domain/icon-192.png
```
Falls dort weiterhin eine Cloudflare-Login-Seite statt der erwarteten Datei
erscheint, kann in Cloudflare Zero Trust eine **Bypass-Regel** nur für diese
vier statischen Pfade eingerichtet werden (`/manifest.json`, `/sw.js`,
`/icon-192.png`, `/icon-512.png`) — das gibt keine Kassendaten frei, nur
App-Metadaten und Icons, die ohnehin keine sensiblen Informationen enthalten.

Nach jeder Code-Änderung an Manifest/Service-Worker: auf dem Tablet unter
Chrome → Website-Einstellungen → "Daten löschen" gehen, da sonst eine alte,
fehlerhafte Service-Worker-Version weiter aktiv bleiben kann.

**Wichtig:** wenn die Access-Session abläuft, müssen Bilder/API-Calls neu
authentifiziert werden — das Tablet zeigt dann ggf. erneut die
Cloudflare-Login-Seite. Für ein dauerhaft "kindersicheres" Setup ohne
wiederkehrende Logins ist es meist einfacher, die Access-Policy entweder zu
entfernen oder eine möglichst lange Session-Dauer einzustellen.

---

## Demo-Daten

Beim ersten Start werden automatisch 51 Beispielartikel mit Bildern angelegt.

## Für das lokale Netz

Damit das Tablet die App erreicht, muss es im **gleichen WLAN** sein wie der Server (oder per Cloudflare Tunnel von überall).

IP-Adresse des Servers im lokalen Netz herausfinden:
```bash
# Linux/Mac
ip a | grep "inet "
# Windows
ipconfig
```

Dann im Browser des Tablets: `http://192.168.x.x:3800` (weder NFC noch QR-Kamera funktionieren ohne HTTPS, siehe oben — werte für beide Methoden müssen dann manuell eingetippt werden).
